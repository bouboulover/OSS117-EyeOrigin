// Projet OSS117 : Eye origin 
// Version 0.0 
// Théo Falgarone, Alexis Hubert, Tristan Maunier, Christian Te


import ij.*;
import ij.gui.*;
import java.awt.*;
import ij.plugin.filter.PlugInFilter;
import ij.process.*;
import java.awt.event.*;
import java.io.*;

// Creer le stack dans imagej :
// File -> import -> image sequence -> sélectioner n'importe quel image du fichier -> cocher: use virtual stack -> OK

public class EyePosition2 implements PlugInFilter, MouseListener
{
    ImagePlus img;
    ImageCanvas canvas;
    int cpt =0;
    
    public int setup(String arg, ImagePlus img)
    {
	this.img = img;
	IJ.register(EyePosition2.class);
	return DOES_ALL+NO_CHANGES;	
    }
    public void run(ImageProcessor ip)
    {
	File f = new File ("position2.txt");
	try
	    {	    
		FileWriter fw = new FileWriter (f);
		fw.write ("Xgauche Ygauche Xdroit Ydroit");
		fw.write ("\n");
		fw.close();
	    }
	catch (IOException exception)
	    {
		System.out.println ("Erreur lors de la lecture : " + exception.getMessage());
	    }
	ImageWindow win = img.getWindow();
	canvas = win.getCanvas();
	canvas.addMouseListener(this);
    }	
    public void mousePressed(MouseEvent e){}
    public void mouseReleased(MouseEvent e){}
    public void mouseExited(MouseEvent e){}  
    
    public void mouseClicked(MouseEvent e)
    {
	cpt++;
	int X = e.getX();
	int Y = e.getY();
	File f = new File ("position2.txt");
	if (cpt == 1){
	    try
		{	    
		    FileWriter fw = new FileWriter (f,true);
		    fw.write (String.valueOf (X));
		    fw.write (" ");
		    fw.write (String.valueOf (Y));
		    fw.close();
		}
	    catch (IOException exception)
		{
		    System.out.println ("Erreur lors de la lecture : " + exception.getMessage());
		}
	}
	if (cpt == 2){
	    try
		{	    
		    FileWriter fw = new FileWriter (f,true);
		    fw.write (" ");
		    fw.write (String.valueOf (X));
		    fw.write (" ");
		    fw.write (String.valueOf (Y));
		    fw.write ("\n");
		    fw.close();
		    IJ.run(img, "Next Slice [>]", "");
		    cpt = 0;		   
		}
	    catch (IOException exception)
		{
		    System.out.println ("Erreur lors de la lecture : " + exception.getMessage());
		}
	}
	IJ.log("x: "+X+"  y: "+Y);
    }	
    public void mouseEntered(MouseEvent e){}
}
